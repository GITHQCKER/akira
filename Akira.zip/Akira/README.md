

</p>
</div>


# Instalasi
## Akirachan99 Buildpack

Click the deploy icon below !

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Akirachan99/akira)

```bash
 > heroku/nodejs
 > https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest
 > https://github.com/clhuang/heroku-buildpack-webp-binaries.git
```

## Termux
```bash
> apt update && apt upgrade
> pkg install libweb nodejs git ffmpeg
> git clone https://github.com/Akirachan99/akira.git
> cd Akira
> npm install
> node haruka.js
```

## settings
You can edit owner and other in `'./settings/config.json'`

```ts
{
	"ownername":"AkiraYT",
	"ownernumber":"6281327327914",
	"botname":"AKIRA-Bot",
	"thumbnail":"./settings/haruka.jpg",
	"session_name":"./session.json"
}
```
## Donate
- [Saweria](https://saweria.co/akir4)
- [Dana](https://link.dana.id/minta/2prq0m274ys)



# Thanks To
- My god & my parents
- Penyedia module
- Teman" yang selalu support saya
- Kalian semua 🛐
